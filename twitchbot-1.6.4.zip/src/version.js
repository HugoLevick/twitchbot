const footer = document.getElementById("version");
footer.innerHTML = "v1.1.1 - by h_levick";
